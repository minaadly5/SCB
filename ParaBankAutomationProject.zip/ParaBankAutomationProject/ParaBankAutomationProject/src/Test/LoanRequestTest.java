package Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Procedures.LoanRequest;

public class LoanRequestTest {
	
	private WebDriver driver;
    private LoanRequest LoanProceduresInstance;
    
    @BeforeTest
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://parabank.parasoft.com/parabank/index.htm");
        
        System.out.println("Loan Request TestCase");
        // Initialize Procedures
        LoanProceduresInstance = new LoanRequest();
    }
    
    @Test
    public void testLogin() throws InterruptedException {
    	LoanProceduresInstance.LoanRequestSteps(driver);
    }
    
    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

}
