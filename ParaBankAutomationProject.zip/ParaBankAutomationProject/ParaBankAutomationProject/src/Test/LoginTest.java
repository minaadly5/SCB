package Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Procedures.Login;

public class LoginTest {
	
	private WebDriver driver;
    private Login LoginProceduresInstance;
    
    @BeforeTest
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://parabank.parasoft.com/parabank/index.htm");

        System.out.println("Login TestCase");
        // Initialize Procedures
        LoginProceduresInstance = new Login();
    }
    
    @Test
    public void testLogin() throws InterruptedException {
    	LoginProceduresInstance.LoginSteps(driver);
    }
    
    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

}
