package Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import Procedures.TransferFund;

public class TransferFundTest {
	
	private WebDriver driver;
    private TransferFund TransferProceduresInstance;
    
    @BeforeTest
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://parabank.parasoft.com/parabank/index.htm");

        
        System.out.println("Fund Transfer TestCase");
        // Initialize Procedures
        TransferProceduresInstance = new TransferFund();
    }
    
    @Test
    public void testLogin() throws InterruptedException {
    	TransferProceduresInstance.FundTransferSteps(driver);
    }
    
    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

}
