package Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Procedures.LogOut;

public class LogOutTest {
	
	private WebDriver driver;
    private LogOut LogOutProceduresInstance;
    
    @BeforeTest
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://parabank.parasoft.com/parabank/index.htm");

        System.out.println("LogOut TestCase");
        // Initialize Procedures
        LogOutProceduresInstance = new LogOut();
    }
    
    @Test
    public void testLogin() throws InterruptedException {
    	LogOutProceduresInstance.LogOutSteps(driver);
    }
    
    @AfterTest
    public void tearDown() {
        // Close the browser
        driver.quit();
    }

}
