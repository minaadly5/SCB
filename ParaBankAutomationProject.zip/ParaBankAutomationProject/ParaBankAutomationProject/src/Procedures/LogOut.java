package Procedures;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageObject.LogOutPageObject;
import ProjectData.ProjectData;

/*LogOut Procedures class contain the logic of the TC*/

public class LogOut {

	private LogOutPageObject LogOutPageObjectInstance;
	private ProjectData dataInstance;

	public void LogOutSteps(WebDriver driver) throws InterruptedException{

		// Initialize Page Object
		LogOutPageObjectInstance = new LogOutPageObject();
		// Initialize data
		dataInstance = new ProjectData();
		
		LogOutPageObjectInstance.EnterUserName(driver, dataInstance.getUserName())
				.EnterPassword(driver, dataInstance.getLoginPassword())
				.ClickLoginButton(driver);
		
		Thread.sleep(5000);
		LogOutPageObjectInstance.ClickLogOutButton(driver);
		
		if(LogOutPageObjectInstance.VerifyLoginButtonExist(driver))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertFalse(false);
		}
		Thread.sleep(5000);
	}

}
