package Procedures;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageObject.RequestLoanPageObject;
import ProjectData.ProjectData;

/*Loan Request Procedures class contain the logic of the TC*/
public class LoanRequest {

	private RequestLoanPageObject LoanPageObjectInstance;
	private ProjectData dataInstance;

	public void LoanRequestSteps(WebDriver driver) throws InterruptedException{

		// Initialize Page Object
		LoanPageObjectInstance = new RequestLoanPageObject();
		// Initialize data
		dataInstance = new ProjectData();

		LoanPageObjectInstance.EnterUserName(driver, dataInstance.getUserName())
				.EnterPassword(driver, dataInstance.getLoginPassword())
				.ClickLoginButton(driver)
				.verifyLogOutButtonExist(driver);
		
		Thread.sleep(5000);
		
		LoanPageObjectInstance.ClickRequestLoan(driver);
		Thread.sleep(4000);
		
		LoanPageObjectInstance.EnterLoanAmount(driver, dataInstance.getLoanAmount())
				.EnterLoanDownPayment(driver, dataInstance.getLoanDownPayment())
				.ChooseFromAccountDDL(driver, dataInstance.getFromAccount())
				.ClickApply(driver);
		
		Thread.sleep(5000);
		
		if(LoanPageObjectInstance.verifyLoanStatusIsApproved(driver))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertFalse(false);
		}
		
		LoanPageObjectInstance.ClickLogOutButton(driver);
		Thread.sleep(5000);

	}

}
