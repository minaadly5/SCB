package Procedures;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageObject.RegisterPageObject;
import ProjectData.ProjectData;

/*Register Procedures class contain the logic of the TC*/

public class Register {

	private RegisterPageObject RegisterPageObjectInstance;
	private ProjectData dataInstance;

	public void RegisterSteps(WebDriver driver) throws InterruptedException{

		// Initialize Page Object
		RegisterPageObjectInstance = new RegisterPageObject();
		// Initialize data
		dataInstance = new ProjectData();

		RegisterPageObjectInstance.ClickOnRegisterButton(driver)
				.EnterFirstName(driver, dataInstance.getFirstName())
				.EnterLastName(driver, dataInstance.getLastName())
				.EnterAddress(driver, dataInstance.getAddress())
				.EnterCity(driver, dataInstance.getCity())
				.EnterState(driver, dataInstance.getState())
				.EnterPhoneNumber(driver, dataInstance.getPhoneNumber())
				.EnterZipCode(driver, dataInstance.getZipCode())
				.EnterSSN(driver, dataInstance.getSsn())
				.EnterUserName(driver, dataInstance.getUserName())
				.EnterPassword(driver, dataInstance.getRegisterPassword())
				.EnterConfirmPassword(driver, dataInstance.getConfirmPassowrd())
				.ClickFinalRegister(driver);
		Thread.sleep(5000);
		
		if(RegisterPageObjectInstance.verifyAccountCreated(driver))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertFalse(false);
		}
		
		RegisterPageObjectInstance.ClickLogOutButton(driver);
		Thread.sleep(5000);

	}

}
