package Procedures;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageObject.LoginPageObject;
import ProjectData.ProjectData;

/*Login Procedures class contain the logic of the TC*/

public class Login {

	private LoginPageObject LoginPageObjectInstance;
	private ProjectData dataInstance;

	public void LoginSteps(WebDriver driver) throws InterruptedException{

		// Initialize Page Object
		LoginPageObjectInstance = new LoginPageObject();
		// Initialize data
		dataInstance = new ProjectData();
		
		LoginPageObjectInstance.EnterUserName(driver, dataInstance.getUserName())
				.EnterPassword(driver, dataInstance.getLoginPassword())
				.ClickLoginButton(driver);
		
		Thread.sleep(5000);
		
		if(LoginPageObjectInstance.verifyLogOutButtonExist(driver))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertFalse(false);
		}
		
		LoginPageObjectInstance.ClickLogOutButton(driver);
		Thread.sleep(5000);

	}

}
