package Procedures;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import PageObject.TransferFundPageObject;
import ProjectData.ProjectData;

/*Register Procedures class contain the logic of the TC*/

public class TransferFund {

	private TransferFundPageObject TransferPageObjectInstance;
	private ProjectData dataInstance;

	public void FundTransferSteps(WebDriver driver) throws InterruptedException{

		// Initialize Page Object
		TransferPageObjectInstance = new TransferFundPageObject();
		// Initialize data
		dataInstance = new ProjectData();
		
		TransferPageObjectInstance.EnterUserName(driver,dataInstance.getUserName() )
				.EnterPassword(driver, dataInstance.getLoginPassword())
				.ClickLoginButton(driver)
				.verifyLogOutButtonExist(driver);
		
		Thread.sleep(5000);
		
		TransferPageObjectInstance.ClickFundTransferButton(driver);
		Thread.sleep(5000);
		TransferPageObjectInstance.EnterAmount(driver, dataInstance.getFundAmount())
				.ChooseFromAccountDDL(driver, dataInstance.getFromAccount())
				.ChooseToAccountDDL(driver, dataInstance.getToAccount())
				.ClickTransferButton(driver);
		
		Thread.sleep(5000);
		
		if(TransferPageObjectInstance.verifyTransferCompleteMsgAppear(driver))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertFalse(false);
		}
		
		TransferPageObjectInstance.ClickLogOutButton(driver);
		Thread.sleep(5000);
	}

}
