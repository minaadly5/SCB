package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


/*Register Page Object class Contain all needed locators and methods to complete the TC*/

public class RegisterPageObject {


		public RegisterPageObject ClickOnRegisterButton (WebDriver driver)
		{
			WebElement registerButton =driver.findElement(By.xpath("//a[text()='Register']"));
			registerButton.click();
			
			return this;
		}
		
		public RegisterPageObject EnterFirstName (WebDriver driver,String firstName)
		{
			WebElement firstNameTextField =driver.findElement(By.xpath("//input[@id='customer.firstName']"));
			firstNameTextField.sendKeys(firstName);
			
			return this;
		}
		
		public RegisterPageObject EnterLastName (WebDriver driver,String lastName)
		{
			WebElement secondNameTextField =driver.findElement(By.xpath("//input[@id='customer.lastName']"));
			secondNameTextField.sendKeys(lastName);
			
			return this;
		}
		
		public RegisterPageObject EnterAddress (WebDriver driver,String address)
		{
			WebElement addressTextField =driver.findElement(By.xpath("//input[@id='customer.address.street']"));
			addressTextField.sendKeys(address);
			
			return this;
		}
		
		public RegisterPageObject EnterCity (WebDriver driver,String city)
		{
			WebElement cityTextField =driver.findElement(By.xpath("//input[@id='customer.address.city']"));
			cityTextField.sendKeys(city);
			
			return this;
		}
		
		public RegisterPageObject EnterState (WebDriver driver,String state)
		{
			WebElement stateTextField =driver.findElement(By.xpath("//input[@id='customer.address.state']"));
			stateTextField.sendKeys(state);
			
			return this;
		}
		
		public RegisterPageObject EnterZipCode (WebDriver driver,String state)
		{
			WebElement zipCodeTextField =driver.findElement(By.xpath("//input[@id='customer.address.zipCode']"));
			zipCodeTextField.sendKeys(state);
			
			return this;
		}
		
		public RegisterPageObject EnterPhoneNumber (WebDriver driver,String number)
		{
			WebElement phoneNumberTextField =driver.findElement(By.xpath("//input[@id='customer.phoneNumber']"));
			phoneNumberTextField.sendKeys(number);
			
			return this;
		}
		
		public RegisterPageObject EnterSSN (WebDriver driver,String ssn)
		{
			WebElement SNNTextField =driver.findElement(By.xpath("//input[@id='customer.ssn']"));
			SNNTextField.sendKeys(ssn);
			
			return this;
		}
		
		public RegisterPageObject EnterUserName (WebDriver driver,String userName)
		{
			WebElement userNameTextField =driver.findElement(By.xpath("//input[@id='customer.username']"));
			userNameTextField.sendKeys(userName);
			
			return this;
		}
		
		public RegisterPageObject EnterPassword (WebDriver driver,String password)
		{
			WebElement passwordTextField =driver.findElement(By.xpath("//input[@id='customer.password']"));
			passwordTextField.sendKeys(password);
			
			return this;
		}
		
		public RegisterPageObject EnterConfirmPassword (WebDriver driver,String password)
		{
			WebElement confirmPasswordTextField =driver.findElement(By.xpath("//input[@id='repeatedPassword']"));
			confirmPasswordTextField.sendKeys(password);
			
			return this;
		}
		
		public RegisterPageObject ClickFinalRegister (WebDriver driver)
		{
			WebElement registerButton =driver.findElement(By.xpath("//input[@value='Register']"));
			registerButton.click();
			
			return this;
		}
		
		public boolean verifyAccountCreated (WebDriver driver)
		{
			WebElement sucessMessage =driver.findElement(By.xpath("//p[contains(text(), 'Your account was created successfully')]"));
			
			if(sucessMessage.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		}
		
		public RegisterPageObject ClickLogOutButton (WebDriver driver)
		{
			WebElement LogOutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			LogOutButton.click();
			
			return this;
		}
		
		

}
