package PageObject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/*Transfer Fund Page Object class Contain all needed locators and methods to complete the TC*/

public class TransferFundPageObject {


		public TransferFundPageObject EnterUserName (WebDriver driver,String username)
		{
			WebElement usernameTextField =driver.findElement(By.xpath("//input[@name='username']"));
			usernameTextField.sendKeys(username);
			
			return this;
		}
		public TransferFundPageObject EnterPassword (WebDriver driver,String password)
		{
			WebElement passwordTextField =driver.findElement(By.xpath("//input[@name='password']"));
			passwordTextField.sendKeys(password);
			
			return this;
		}
		
		public TransferFundPageObject ClickLoginButton (WebDriver driver)
		{
			WebElement LoginButton =driver.findElement(By.xpath("//input[@class='button']"));
			LoginButton.click();
			
			return this;
		}
		
		
		public boolean verifyLogOutButtonExist (WebDriver driver)
		{
			WebElement logoutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			
			if(logoutButton.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}
			
		}
		
		public TransferFundPageObject ClickLogOutButton (WebDriver driver)
		{
			WebElement LogOutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			LogOutButton.click();
			
			return this;
		}
		
		public TransferFundPageObject ClickFundTransferButton (WebDriver driver)
		{
			WebElement fundTransferButton =driver.findElement(By.xpath("//a[text()='Transfer Funds']"));
			fundTransferButton.click();
			
			return this;
		}
		
		public TransferFundPageObject EnterAmount (WebDriver driver,String amount)
		{
			WebElement amountTextField =driver.findElement(By.xpath("//input[@id='amount']"));
			amountTextField.sendKeys(amount);
			
			return this;
		}
		
		public TransferFundPageObject ChooseFromAccountDDL (WebDriver driver,String account)
		{
			WebElement accountDDL =driver.findElement(By.xpath("//select[@id='fromAccountId']"));
			accountDDL.click();
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			//WebElement accountValue =driver.findElement(By.xpath("//select[@id='fromAccountId']/option[@value='"+account+"']"));
			/*The account number changes with every customer*/
			
			WebElement accountValue =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//select[@id='fromAccountId']/option)[1]")));
			accountValue.click();
			
			return this;
		}
		
		public TransferFundPageObject ChooseToAccountDDL (WebDriver driver,String account)
		{
			WebElement accountDDL =driver.findElement(By.xpath("//select[@id='toAccountId']"));
			accountDDL.click();
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			//WebElement accountValue =driver.findElement(By.xpath("//select[@id='toAccountId']/option[@value='"+account+"']"));
			/*The account number changes with every customer*/
			WebElement accountValue =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//select[@id='toAccountId']/option)[1]")));
			accountValue.click();
			
			return this;
		}
		
		public TransferFundPageObject ClickTransferButton (WebDriver driver)
		{
			WebElement TransferButton =driver.findElement(By.xpath("//input[@value='Transfer']"));
			TransferButton.click();
			
			return this;
		}
		
		public boolean verifyTransferCompleteMsgAppear (WebDriver driver)
		{
			WebElement transferCompleteMsg =driver.findElement(By.xpath("//h1[text()='Transfer Complete!']"));
			
			if(transferCompleteMsg.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}
			
		}
		
		

}
