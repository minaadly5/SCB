package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/*Login Page Object class Contain all needed locators and methods to complete the TC*/
public class LoginPageObject {


		public LoginPageObject EnterUserName (WebDriver driver,String username)
		{
			WebElement usernameTextField =driver.findElement(By.xpath("//input[@name='username']"));
			usernameTextField.sendKeys(username);
			
			return this;
		}
		public LoginPageObject EnterPassword (WebDriver driver,String password)
		{
			WebElement passwordTextField =driver.findElement(By.xpath("//input[@name='password']"));
			passwordTextField.sendKeys(password);
			
			return this;
		}
		
		public LoginPageObject ClickLoginButton (WebDriver driver)
		{
			WebElement LoginButton =driver.findElement(By.xpath("//input[@class='button']"));
			LoginButton.click();
			
			return this;
		}
		
		
		public boolean verifyLogOutButtonExist (WebDriver driver)
		{
			WebElement logoutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			
			if(logoutButton.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		}
		
		public LoginPageObject ClickLogOutButton (WebDriver driver)
		{
			WebElement LogOutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			LogOutButton.click();
			
			return this;
		}
		

		

}
