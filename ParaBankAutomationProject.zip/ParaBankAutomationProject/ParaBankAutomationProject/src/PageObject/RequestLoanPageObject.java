package PageObject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


/*Request Loan Page Object class Contain all needed locators and methods to complete the TC*/

public class RequestLoanPageObject {


		public RequestLoanPageObject EnterUserName (WebDriver driver,String username)
		{
			WebElement usernameTextField =driver.findElement(By.xpath("//input[@name='username']"));
			usernameTextField.sendKeys(username);
			
			return this;
		}
		public RequestLoanPageObject EnterPassword (WebDriver driver,String password)
		{
			WebElement passwordTextField =driver.findElement(By.xpath("//input[@name='password']"));
			passwordTextField.sendKeys(password);
			
			return this;
		}
		
		public RequestLoanPageObject ClickLoginButton (WebDriver driver)
		{
			WebElement LoginButton =driver.findElement(By.xpath("//input[@class='button']"));
			LoginButton.click();
			
			return this;
		}
		
		
		public boolean verifyLogOutButtonExist (WebDriver driver)
		{
			WebElement logoutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			
			if(logoutButton.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		}
		
		public RequestLoanPageObject ClickLogOutButton (WebDriver driver)
		{
			WebElement LogOutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			LogOutButton.click();
			
			return this;
		}
		
		public RequestLoanPageObject ClickRequestLoan (WebDriver driver)
		{
			WebElement requestLoanButton =driver.findElement(By.xpath("//a[text()='Request Loan']"));
			requestLoanButton.click();
			
			return this;
		}
		
		public RequestLoanPageObject EnterLoanAmount (WebDriver driver,String loanAmount)
		{
			WebElement loanAmountTextField = driver.findElement(By.xpath("//input[@id='amount']"));
			loanAmountTextField.sendKeys(loanAmount);
			
			return this;
		}
		
		public RequestLoanPageObject EnterLoanDownPayment (WebDriver driver,String downPayment)
		{
			WebElement loanDownPaymentTextField = driver.findElement(By.xpath("//input[@id='downPayment']"));
			loanDownPaymentTextField.sendKeys(downPayment);
			
			return this;
		}
		
		
		public RequestLoanPageObject ChooseFromAccountDDL (WebDriver driver,String account)
		{
			WebElement accountDDL =driver.findElement(By.xpath("//select[@id='fromAccountId']"));
			accountDDL.click();
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			//WebElement accountValue =driver.findElement(By.xpath("//select[@id='fromAccountId']/option[@value='"+account+"']"));
			/*The account number changes with every customer*/
			
			WebElement accountValue =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//select[@id='fromAccountId']/option)[1]")));
			accountValue.click();
			
			return this;
		}

		public RequestLoanPageObject ClickApply (WebDriver driver)
		{
			WebElement ApplyButton =driver.findElement(By.xpath("//input[@value='Apply Now']"));
			ApplyButton.click();
			
			return this;
		}
		
		public boolean verifyLoanStatusIsApproved (WebDriver driver)
		{
			WebElement loanStatus =driver.findElement(By.xpath("//td[@id='loanStatus']"));
			String status=loanStatus.getText();
			
			if(status.equals("Approved"))
			{
				return true;
			}
			else
			{
				return false;
			}
			
			
		}
		

}
