package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/*Logout Page Object class Contain all needed locators and methods to complete the TC*/

public class LogOutPageObject {


		public LogOutPageObject EnterUserName (WebDriver driver,String username)
		{
			WebElement usernameTextField =driver.findElement(By.xpath("//input[@name='username']"));
			usernameTextField.sendKeys(username);
			
			return this;
		}
		public LogOutPageObject EnterPassword (WebDriver driver,String password)
		{
			WebElement passwordTextField =driver.findElement(By.xpath("//input[@name='password']"));
			passwordTextField.sendKeys(password);
			
			return this;
		}
		
		public LogOutPageObject ClickLoginButton (WebDriver driver)
		{
			WebElement LoginButton =driver.findElement(By.xpath("//input[@class='button']"));
			LoginButton.click();
			
			return this;
		}
		

		
		public LogOutPageObject ClickLogOutButton (WebDriver driver)
		{
			WebElement LogOutButton =driver.findElement(By.xpath("//a[text()='Log Out']"));
			LogOutButton.click();
			
			return this;
		}
		
		public boolean VerifyLoginButtonExist (WebDriver driver)
		{
			WebElement LoginButton =driver.findElement(By.xpath("//input[@class='button']"));
			
			if(LoginButton.isDisplayed())
			{
				return true;
			}
			else
			{
				return false;
			}	
		}
		

}
