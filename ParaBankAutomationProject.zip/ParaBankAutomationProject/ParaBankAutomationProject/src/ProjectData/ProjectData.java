package ProjectData;

/*Data Class contains all mandatory data for the project*/
public class ProjectData {

	private String userName = "Mina39";
	private String loginPassword= "1234";
	private String firstName = "Mina";
	private String lastName="Adly";
	private String address="Giza";
	private String city = "Cairo";
	private String state = "Cairo";
	private String phoneNumber= "01263579436";
	private String zipCode="12512";
	private String ssn = "563";
	private String registerPassword = "1234";
	private String confirmPassowrd="1234";
	private String loanAmount = "100";
	private String loanDownPayment = "0";
	private String fromAccount="13733"; // Not used due to the continuous changing of the number
	private String toAccount="13733"; // Not used due to the continuous changing of the number
	private String fundAmount = "100";
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getRegisterPassword() {
		return registerPassword;
	}

	public void setRegisterPassword(String registerPassword) {
		this.registerPassword = registerPassword;
	}

	public String getConfirmPassowrd() {
		return confirmPassowrd;
	}

	public void setConfirmPassowrd(String confirmPassowrd) {
		this.confirmPassowrd = confirmPassowrd;
	}

	public String getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}

	public String getLoanDownPayment() {
		return loanDownPayment;
	}

	public void setLoanDownPayment(String loanDownPayment) {
		this.loanDownPayment = loanDownPayment;
	}

	public String getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(String fromAccount) {
		this.fromAccount = fromAccount;
	}

	public String getFundAmount() {
		return fundAmount;
	}

	public void setFundAmount(String fundAmount) {
		this.fundAmount = fundAmount;
	}

	public String getToAccount() {
		return toAccount;
	}

	public void setToAccount(String toAccount) {
		this.toAccount = toAccount;
	}
	

}
